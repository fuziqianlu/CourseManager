/********************************************************************************
** Form generated from reading UI file 'ManagerWin.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGERWIN_H
#define UI_MANAGERWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ManagerWin
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_17;
    QSpacerItem *horizontalSpacer_13;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_12;
    QLabel *label_13;
    QSpacerItem *horizontalSpacer_8;
    QLabel *label_14;
    QLabel *label_15;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_25;
    QHBoxLayout *horizontalLayout;
    QLabel *label_8;
    QLineEdit *lineEdit_4;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_9;
    QLineEdit *lineEdit_5;
    QComboBox *comboBox_6;
    QHBoxLayout *horizontalLayout_26;
    QSpacerItem *horizontalSpacer_9;
    QHBoxLayout *horizontalLayout_12;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_4;
    QTreeWidget *treeWidget_2;
    QHBoxLayout *horizontalLayout_21;
    QSpacerItem *horizontalSpacer_14;
    QPushButton *pushButton_16;
    QSpacerItem *horizontalSpacer_15;
    QPushButton *pushButton_17;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QComboBox *comboBox;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_7;
    QLineEdit *lineEdit_3;
    QComboBox *comboBox_4;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_2;
    QTreeWidget *treeWidget;
    QHBoxLayout *horizontalLayout_32;
    QSpacerItem *horizontalSpacer_16;
    QPushButton *pushButton_14;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_5;
    QTabWidget *tabWidget_3;
    QWidget *tab_7;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_27;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_19;
    QLineEdit *lineEdit_11;
    QSpacerItem *horizontalSpacer_10;
    QHBoxLayout *horizontalLayout_29;
    QLabel *label_20;
    QLineEdit *lineEdit_12;
    QComboBox *comboBox_14;
    QHBoxLayout *horizontalLayout_30;
    QSpacerItem *horizontalSpacer_11;
    QHBoxLayout *horizontalLayout_31;
    QPushButton *pushButton_9;
    QSpacerItem *horizontalSpacer_12;
    QPushButton *pushButton_10;
    QTreeWidget *treeWidget_5;
    QHBoxLayout *horizontalLayout_33;
    QSpacerItem *horizontalSpacer_17;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QWidget *tab_8;
    QVBoxLayout *verticalLayout_3;
    QTreeWidget *treeWidget_3;
    QHBoxLayout *horizontalLayout_14;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QWidget *tab_4;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_16;
    QLineEdit *lineEdit_8;
    QPushButton *pushButton_11;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_24;
    QLineEdit *lineEdit_13;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_23;
    QLineEdit *lineEdit_14;
    QWidget *layoutWidget_5;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_18;
    QLineEdit *lineEdit_10;
    QWidget *layoutWidget_6;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_21;
    QLineEdit *lineEdit_15;
    QWidget *tab_5;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_44;
    QHBoxLayout *horizontalLayout_40;
    QLabel *label_26;
    QLineEdit *lineEdit_18;
    QSpacerItem *horizontalSpacer_22;
    QHBoxLayout *horizontalLayout_42;
    QLabel *label_27;
    QLineEdit *lineEdit_19;
    QComboBox *comboBox_18;
    QHBoxLayout *horizontalLayout_41;
    QSpacerItem *horizontalSpacer_24;
    QPushButton *pushButton_24;
    QSpacerItem *horizontalSpacer_25;
    QPushButton *pushButton_25;
    QTreeWidget *treeWidget_6;
    QHBoxLayout *horizontalLayout_43;
    QSpacerItem *horizontalSpacer_23;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ManagerWin)
    {
        if (ManagerWin->objectName().isEmpty())
            ManagerWin->setObjectName(QStringLiteral("ManagerWin"));
        ManagerWin->resize(777, 565);
        centralWidget = new QWidget(ManagerWin);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout_6 = new QVBoxLayout(centralWidget);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        horizontalSpacer_13 = new QSpacerItem(478, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_13);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_19->addWidget(label_12);

        label_13 = new QLabel(centralWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout_19->addWidget(label_13);

        horizontalSpacer_8 = new QSpacerItem(58, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_8);

        label_14 = new QLabel(centralWidget);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_19->addWidget(label_14);

        label_15 = new QLabel(centralWidget);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_19->addWidget(label_15);


        horizontalLayout_17->addLayout(horizontalLayout_19);


        verticalLayout_6->addLayout(horizontalLayout_17);

        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setTabPosition(QTabWidget::North);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout = new QVBoxLayout(tab);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_8 = new QLabel(tab);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout->addWidget(label_8);

        lineEdit_4 = new QLineEdit(tab);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        horizontalLayout->addWidget(lineEdit_4);


        horizontalLayout_25->addLayout(horizontalLayout);

        horizontalSpacer_4 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_4);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_9 = new QLabel(tab);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_11->addWidget(label_9);

        lineEdit_5 = new QLineEdit(tab);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));

        horizontalLayout_11->addWidget(lineEdit_5);

        comboBox_6 = new QComboBox(tab);
        comboBox_6->setObjectName(QStringLiteral("comboBox_6"));

        horizontalLayout_11->addWidget(comboBox_6);


        horizontalLayout_25->addLayout(horizontalLayout_11);


        verticalLayout->addLayout(horizontalLayout_25);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        horizontalSpacer_9 = new QSpacerItem(328, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_26->addItem(horizontalSpacer_9);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout_12->addWidget(pushButton_3);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_3);

        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        horizontalLayout_12->addWidget(pushButton_4);


        horizontalLayout_26->addLayout(horizontalLayout_12);


        verticalLayout->addLayout(horizontalLayout_26);

        treeWidget_2 = new QTreeWidget(tab);
        treeWidget_2->setObjectName(QStringLiteral("treeWidget_2"));
        treeWidget_2->header()->setDefaultSectionSize(90);

        verticalLayout->addWidget(treeWidget_2);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        horizontalSpacer_14 = new QSpacerItem(528, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_14);

        pushButton_16 = new QPushButton(tab);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));

        horizontalLayout_21->addWidget(pushButton_16);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_15);

        pushButton_17 = new QPushButton(tab);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));

        horizontalLayout_21->addWidget(pushButton_17);


        verticalLayout->addLayout(horizontalLayout_21);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout_2 = new QVBoxLayout(tab_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label = new QLabel(tab_2);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        lineEdit = new QLineEdit(tab_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_2->addWidget(lineEdit);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        horizontalSpacer = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_2 = new QLabel(tab_2);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_10->addWidget(label_2);

        lineEdit_2 = new QLineEdit(tab_2);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout_10->addWidget(lineEdit_2);

        comboBox = new QComboBox(tab_2);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setMaxVisibleItems(10);
        comboBox->setInsertPolicy(QComboBox::InsertAtBottom);

        horizontalLayout_10->addWidget(comboBox);


        horizontalLayout_4->addLayout(horizontalLayout_10);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_8->addWidget(label_7);

        lineEdit_3 = new QLineEdit(tab_2);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        horizontalLayout_8->addWidget(lineEdit_3);

        comboBox_4 = new QComboBox(tab_2);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));

        horizontalLayout_8->addWidget(comboBox_4);


        verticalLayout_2->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout_9->addWidget(pushButton);

        horizontalSpacer_2 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_2);

        pushButton_2 = new QPushButton(tab_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout_9->addWidget(pushButton_2);


        verticalLayout_2->addLayout(horizontalLayout_9);

        treeWidget = new QTreeWidget(tab_2);
        treeWidget->setObjectName(QStringLiteral("treeWidget"));
        treeWidget->header()->setDefaultSectionSize(90);

        verticalLayout_2->addWidget(treeWidget);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setSpacing(6);
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        horizontalSpacer_16 = new QSpacerItem(528, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_32->addItem(horizontalSpacer_16);

        pushButton_14 = new QPushButton(tab_2);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));

        horizontalLayout_32->addWidget(pushButton_14);


        verticalLayout_2->addLayout(horizontalLayout_32);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        verticalLayout_5 = new QVBoxLayout(tab_3);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        tabWidget_3 = new QTabWidget(tab_3);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setTabPosition(QTabWidget::West);
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        verticalLayout_4 = new QVBoxLayout(tab_7);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        label_19 = new QLabel(tab_7);
        label_19->setObjectName(QStringLiteral("label_19"));

        horizontalLayout_28->addWidget(label_19);

        lineEdit_11 = new QLineEdit(tab_7);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));

        horizontalLayout_28->addWidget(lineEdit_11);


        horizontalLayout_27->addLayout(horizontalLayout_28);

        horizontalSpacer_10 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_10);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setSpacing(6);
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        label_20 = new QLabel(tab_7);
        label_20->setObjectName(QStringLiteral("label_20"));

        horizontalLayout_29->addWidget(label_20);

        lineEdit_12 = new QLineEdit(tab_7);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));

        horizontalLayout_29->addWidget(lineEdit_12);

        comboBox_14 = new QComboBox(tab_7);
        comboBox_14->setObjectName(QStringLiteral("comboBox_14"));

        horizontalLayout_29->addWidget(comboBox_14);


        horizontalLayout_27->addLayout(horizontalLayout_29);


        verticalLayout_4->addLayout(horizontalLayout_27);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setSpacing(6);
        horizontalLayout_30->setObjectName(QStringLiteral("horizontalLayout_30"));
        horizontalSpacer_11 = new QSpacerItem(328, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_30->addItem(horizontalSpacer_11);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setSpacing(6);
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        pushButton_9 = new QPushButton(tab_7);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));

        horizontalLayout_31->addWidget(pushButton_9);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_12);

        pushButton_10 = new QPushButton(tab_7);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));

        horizontalLayout_31->addWidget(pushButton_10);


        horizontalLayout_30->addLayout(horizontalLayout_31);


        verticalLayout_4->addLayout(horizontalLayout_30);

        treeWidget_5 = new QTreeWidget(tab_7);
        treeWidget_5->setObjectName(QStringLiteral("treeWidget_5"));
        treeWidget_5->header()->setDefaultSectionSize(90);

        verticalLayout_4->addWidget(treeWidget_5);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setSpacing(6);
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        horizontalSpacer_17 = new QSpacerItem(518, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_33->addItem(horizontalSpacer_17);

        pushButton_12 = new QPushButton(tab_7);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));

        horizontalLayout_33->addWidget(pushButton_12);

        pushButton_13 = new QPushButton(tab_7);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));

        horizontalLayout_33->addWidget(pushButton_13);


        verticalLayout_4->addLayout(horizontalLayout_33);

        tabWidget_3->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        verticalLayout_3 = new QVBoxLayout(tab_8);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        treeWidget_3 = new QTreeWidget(tab_8);
        treeWidget_3->setObjectName(QStringLiteral("treeWidget_3"));
        treeWidget_3->header()->setDefaultSectionSize(100);

        verticalLayout_3->addWidget(treeWidget_3);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalSpacer_5 = new QSpacerItem(408, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_5);

        pushButton_5 = new QPushButton(tab_8);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));

        horizontalLayout_14->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(tab_8);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));

        horizontalLayout_14->addWidget(pushButton_6);


        verticalLayout_3->addLayout(horizontalLayout_14);

        tabWidget_3->addTab(tab_8, QString());

        verticalLayout_5->addWidget(tabWidget_3);

        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        layoutWidget = new QWidget(tab_4);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(140, 50, 177, 22));
        horizontalLayout_23 = new QHBoxLayout(layoutWidget);
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        horizontalLayout_23->setContentsMargins(0, 0, 0, 0);
        label_16 = new QLabel(layoutWidget);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_23->addWidget(label_16);

        lineEdit_8 = new QLineEdit(layoutWidget);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));

        horizontalLayout_23->addWidget(lineEdit_8);

        pushButton_11 = new QPushButton(tab_4);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(180, 240, 75, 23));
        layoutWidget_3 = new QWidget(tab_4);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(140, 190, 177, 22));
        horizontalLayout_18 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(0, 0, 0, 0);
        label_24 = new QLabel(layoutWidget_3);
        label_24->setObjectName(QStringLiteral("label_24"));

        horizontalLayout_18->addWidget(label_24);

        lineEdit_13 = new QLineEdit(layoutWidget_3);
        lineEdit_13->setObjectName(QStringLiteral("lineEdit_13"));

        horizontalLayout_18->addWidget(lineEdit_13);

        layoutWidget_4 = new QWidget(tab_4);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(140, 160, 177, 22));
        horizontalLayout_20 = new QHBoxLayout(layoutWidget_4);
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        horizontalLayout_20->setContentsMargins(0, 0, 0, 0);
        label_23 = new QLabel(layoutWidget_4);
        label_23->setObjectName(QStringLiteral("label_23"));

        horizontalLayout_20->addWidget(label_23);

        lineEdit_14 = new QLineEdit(layoutWidget_4);
        lineEdit_14->setObjectName(QStringLiteral("lineEdit_14"));

        horizontalLayout_20->addWidget(lineEdit_14);

        layoutWidget_5 = new QWidget(tab_4);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(140, 90, 177, 22));
        horizontalLayout_22 = new QHBoxLayout(layoutWidget_5);
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        horizontalLayout_22->setContentsMargins(0, 0, 0, 0);
        label_18 = new QLabel(layoutWidget_5);
        label_18->setObjectName(QStringLiteral("label_18"));

        horizontalLayout_22->addWidget(label_18);

        lineEdit_10 = new QLineEdit(layoutWidget_5);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));

        horizontalLayout_22->addWidget(lineEdit_10);

        layoutWidget_6 = new QWidget(tab_4);
        layoutWidget_6->setObjectName(QStringLiteral("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(140, 120, 177, 22));
        horizontalLayout_24 = new QHBoxLayout(layoutWidget_6);
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        horizontalLayout_24->setContentsMargins(0, 0, 0, 0);
        label_21 = new QLabel(layoutWidget_6);
        label_21->setObjectName(QStringLiteral("label_21"));

        horizontalLayout_24->addWidget(label_21);

        lineEdit_15 = new QLineEdit(layoutWidget_6);
        lineEdit_15->setObjectName(QStringLiteral("lineEdit_15"));

        horizontalLayout_24->addWidget(lineEdit_15);

        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        verticalLayout_7 = new QVBoxLayout(tab_5);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setSpacing(6);
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        horizontalLayout_40 = new QHBoxLayout();
        horizontalLayout_40->setSpacing(6);
        horizontalLayout_40->setObjectName(QStringLiteral("horizontalLayout_40"));
        label_26 = new QLabel(tab_5);
        label_26->setObjectName(QStringLiteral("label_26"));

        horizontalLayout_40->addWidget(label_26);

        lineEdit_18 = new QLineEdit(tab_5);
        lineEdit_18->setObjectName(QStringLiteral("lineEdit_18"));

        horizontalLayout_40->addWidget(lineEdit_18);

        horizontalSpacer_22 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_40->addItem(horizontalSpacer_22);


        horizontalLayout_44->addLayout(horizontalLayout_40);

        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setSpacing(6);
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        label_27 = new QLabel(tab_5);
        label_27->setObjectName(QStringLiteral("label_27"));

        horizontalLayout_42->addWidget(label_27);

        lineEdit_19 = new QLineEdit(tab_5);
        lineEdit_19->setObjectName(QStringLiteral("lineEdit_19"));

        horizontalLayout_42->addWidget(lineEdit_19);

        comboBox_18 = new QComboBox(tab_5);
        comboBox_18->setObjectName(QStringLiteral("comboBox_18"));

        horizontalLayout_42->addWidget(comboBox_18);


        horizontalLayout_44->addLayout(horizontalLayout_42);


        verticalLayout_7->addLayout(horizontalLayout_44);

        horizontalLayout_41 = new QHBoxLayout();
        horizontalLayout_41->setSpacing(6);
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        horizontalSpacer_24 = new QSpacerItem(458, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_41->addItem(horizontalSpacer_24);

        pushButton_24 = new QPushButton(tab_5);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));

        horizontalLayout_41->addWidget(pushButton_24);

        horizontalSpacer_25 = new QSpacerItem(58, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_41->addItem(horizontalSpacer_25);

        pushButton_25 = new QPushButton(tab_5);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));

        horizontalLayout_41->addWidget(pushButton_25);


        verticalLayout_7->addLayout(horizontalLayout_41);

        treeWidget_6 = new QTreeWidget(tab_5);
        treeWidget_6->setObjectName(QStringLiteral("treeWidget_6"));
        treeWidget_6->header()->setDefaultSectionSize(90);

        verticalLayout_7->addWidget(treeWidget_6);

        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setSpacing(6);
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        horizontalSpacer_23 = new QSpacerItem(518, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_43->addItem(horizontalSpacer_23);

        pushButton_22 = new QPushButton(tab_5);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));

        horizontalLayout_43->addWidget(pushButton_22);

        pushButton_23 = new QPushButton(tab_5);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));

        horizontalLayout_43->addWidget(pushButton_23);


        verticalLayout_7->addLayout(horizontalLayout_43);

        tabWidget->addTab(tab_5, QString());

        verticalLayout_6->addWidget(tabWidget);

        ManagerWin->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(ManagerWin);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 777, 23));
        ManagerWin->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ManagerWin);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        ManagerWin->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(ManagerWin);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        ManagerWin->setStatusBar(statusBar);

        retranslateUi(ManagerWin);

        tabWidget->setCurrentIndex(0);
        tabWidget_3->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ManagerWin);
    } // setupUi

    void retranslateUi(QMainWindow *ManagerWin)
    {
        ManagerWin->setWindowTitle(QApplication::translate("ManagerWin", "ManagerWin", 0));
        label_12->setText(QApplication::translate("ManagerWin", "\345\247\223\345\220\215\357\274\232", 0));
        label_13->setText(QApplication::translate("ManagerWin", "***", 0));
        label_14->setText(QApplication::translate("ManagerWin", "\347\256\241\347\220\206\345\221\230\350\264\246\345\217\267\357\274\232", 0));
        label_15->setText(QApplication::translate("ManagerWin", "0000000000", 0));
        label_8->setText(QApplication::translate("ManagerWin", "\345\255\246\345\217\267\357\274\232", 0));
        label_9->setText(QApplication::translate("ManagerWin", "\345\247\223\345\220\215\357\274\232", 0));
        comboBox_6->clear();
        comboBox_6->insertItems(0, QStringList()
         << QApplication::translate("ManagerWin", "\346\210\226", 0)
         << QApplication::translate("ManagerWin", "\344\270\216", 0)
        );
        pushButton_3->setText(QApplication::translate("ManagerWin", "\346\220\234\347\264\242", 0));
        pushButton_4->setText(QApplication::translate("ManagerWin", "\346\270\205\347\251\272", 0));
        QTreeWidgetItem *___qtreewidgetitem = treeWidget_2->headerItem();
        ___qtreewidgetitem->setText(5, QApplication::translate("ManagerWin", "\351\202\256\347\256\261", 0));
        ___qtreewidgetitem->setText(4, QApplication::translate("ManagerWin", "\347\224\265\350\257\235", 0));
        ___qtreewidgetitem->setText(3, QApplication::translate("ManagerWin", "\347\217\255\347\272\247", 0));
        ___qtreewidgetitem->setText(2, QApplication::translate("ManagerWin", "\345\271\264\347\272\247", 0));
        ___qtreewidgetitem->setText(1, QApplication::translate("ManagerWin", "\345\255\246\345\217\267", 0));
        ___qtreewidgetitem->setText(0, QApplication::translate("ManagerWin", "\345\247\223\345\220\215", 0));
        pushButton_16->setText(QApplication::translate("ManagerWin", "\346\263\250\345\206\214\345\255\246\347\224\237", 0));
        pushButton_17->setText(QApplication::translate("ManagerWin", "\345\210\240\351\231\244\345\255\246\347\224\237", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("ManagerWin", "\345\255\246\347\224\237\347\256\241\347\220\206", 0));
        label->setText(QApplication::translate("ManagerWin", "\350\257\276\347\250\213\345\217\267\357\274\232", 0));
        label_2->setText(QApplication::translate("ManagerWin", "\350\257\276\347\250\213\345\220\215\347\247\260\357\274\232", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("ManagerWin", "\346\210\226", 0)
         << QApplication::translate("ManagerWin", "\344\270\216", 0)
        );
        comboBox->setCurrentText(QApplication::translate("ManagerWin", "\346\210\226", 0));
        label_7->setText(QApplication::translate("ManagerWin", "\344\270\223\344\270\232\357\274\232", 0));
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("ManagerWin", "\346\210\226", 0)
         << QApplication::translate("ManagerWin", "\344\270\216", 0)
        );
        pushButton->setText(QApplication::translate("ManagerWin", "\346\220\234\347\264\242", 0));
        pushButton_2->setText(QApplication::translate("ManagerWin", "\346\270\205\347\251\272", 0));
        QTreeWidgetItem *___qtreewidgetitem1 = treeWidget->headerItem();
        ___qtreewidgetitem1->setText(3, QApplication::translate("ManagerWin", "\350\257\276\347\250\213\344\273\213\347\273\215", 0));
        ___qtreewidgetitem1->setText(2, QApplication::translate("ManagerWin", "\344\270\223\344\270\232", 0));
        ___qtreewidgetitem1->setText(1, QApplication::translate("ManagerWin", "\350\257\276\347\250\213\345\220\215\347\247\260", 0));
        ___qtreewidgetitem1->setText(0, QApplication::translate("ManagerWin", "\350\257\276\347\250\213\347\274\226\345\217\267", 0));
        pushButton_14->setText(QApplication::translate("ManagerWin", "\345\210\240\351\231\244\350\257\276\347\250\213", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("ManagerWin", "\350\257\276\347\250\213\347\256\241\347\220\206", 0));
        label_19->setText(QApplication::translate("ManagerWin", "\345\267\245\345\217\267\357\274\232", 0));
        label_20->setText(QApplication::translate("ManagerWin", "\345\247\223\345\220\215\357\274\232", 0));
        comboBox_14->clear();
        comboBox_14->insertItems(0, QStringList()
         << QApplication::translate("ManagerWin", "\346\210\226", 0)
         << QApplication::translate("ManagerWin", "\344\270\216", 0)
        );
        pushButton_9->setText(QApplication::translate("ManagerWin", "\346\220\234\347\264\242", 0));
        pushButton_10->setText(QApplication::translate("ManagerWin", "\346\270\205\347\251\272", 0));
        QTreeWidgetItem *___qtreewidgetitem2 = treeWidget_5->headerItem();
        ___qtreewidgetitem2->setText(5, QApplication::translate("ManagerWin", "\344\270\223\344\270\232", 0));
        ___qtreewidgetitem2->setText(4, QApplication::translate("ManagerWin", "\351\202\256\347\256\261", 0));
        ___qtreewidgetitem2->setText(3, QApplication::translate("ManagerWin", "\347\224\265\350\257\235", 0));
        ___qtreewidgetitem2->setText(2, QApplication::translate("ManagerWin", "\350\201\214\347\247\260", 0));
        ___qtreewidgetitem2->setText(1, QApplication::translate("ManagerWin", "\345\247\223\345\220\215", 0));
        ___qtreewidgetitem2->setText(0, QApplication::translate("ManagerWin", "\345\267\245\345\217\267", 0));
        pushButton_12->setText(QApplication::translate("ManagerWin", "\345\242\236\345\212\240\346\225\231\345\270\210", 0));
        pushButton_13->setText(QApplication::translate("ManagerWin", "\345\210\240\351\231\244\346\225\231\345\270\210", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_7), QApplication::translate("ManagerWin", "\346\225\231\345\270\210\345\242\236\345\210\240", 0));
        QTreeWidgetItem *___qtreewidgetitem3 = treeWidget_3->headerItem();
        ___qtreewidgetitem3->setText(4, QApplication::translate("ManagerWin", "\344\273\213\347\273\215", 0));
        ___qtreewidgetitem3->setText(3, QApplication::translate("ManagerWin", "\344\270\223\344\270\232", 0));
        ___qtreewidgetitem3->setText(2, QApplication::translate("ManagerWin", "\350\257\276\347\250\213\345\220\215\347\247\260", 0));
        ___qtreewidgetitem3->setText(1, QApplication::translate("ManagerWin", "\347\224\263\350\257\267\346\225\231\345\270\210\347\274\226\345\217\267", 0));
        ___qtreewidgetitem3->setText(0, QApplication::translate("ManagerWin", "\350\257\276\347\250\213\347\274\226\345\217\267", 0));
        pushButton_5->setText(QApplication::translate("ManagerWin", "\351\200\232\350\277\207\345\256\241\346\240\270", 0));
        pushButton_6->setText(QApplication::translate("ManagerWin", "\345\210\240\351\231\244\347\224\263\350\257\267", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_8), QApplication::translate("ManagerWin", "\350\257\276\347\250\213\347\224\263\350\257\267\345\256\241\346\240\270", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("ManagerWin", "\346\225\231\345\270\210\347\256\241\347\220\206", 0));
        label_16->setText(QApplication::translate("ManagerWin", "\347\274\226\345\217\267\357\274\232", 0));
        pushButton_11->setText(QApplication::translate("ManagerWin", " \346\211\247\350\241\214\344\277\256\346\224\271", 0));
        label_24->setText(QApplication::translate("ManagerWin", "\351\202\256\347\256\261\357\274\232", 0));
        label_23->setText(QApplication::translate("ManagerWin", "\347\224\265\350\257\235\357\274\232", 0));
        label_18->setText(QApplication::translate("ManagerWin", "\345\247\223\345\220\215\357\274\232", 0));
        label_21->setText(QApplication::translate("ManagerWin", "\344\270\223\344\270\232\357\274\232", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("ManagerWin", "\344\270\252\344\272\272\344\277\241\346\201\257\344\277\256\346\224\271", 0));
        label_26->setText(QApplication::translate("ManagerWin", "\345\247\223\345\220\215\357\274\232", 0));
        label_27->setText(QApplication::translate("ManagerWin", "\347\274\226\345\217\267\357\274\232", 0));
        comboBox_18->clear();
        comboBox_18->insertItems(0, QStringList()
         << QApplication::translate("ManagerWin", "\346\210\226", 0)
         << QApplication::translate("ManagerWin", "\344\270\216", 0)
        );
        pushButton_24->setText(QApplication::translate("ManagerWin", "\346\220\234\347\264\242", 0));
        pushButton_25->setText(QApplication::translate("ManagerWin", "\346\270\205\347\251\272", 0));
        QTreeWidgetItem *___qtreewidgetitem4 = treeWidget_6->headerItem();
        ___qtreewidgetitem4->setText(4, QApplication::translate("ManagerWin", "\344\270\223\344\270\232", 0));
        ___qtreewidgetitem4->setText(3, QApplication::translate("ManagerWin", "\351\202\256\347\256\261", 0));
        ___qtreewidgetitem4->setText(2, QApplication::translate("ManagerWin", "\347\224\265\350\257\235", 0));
        ___qtreewidgetitem4->setText(1, QApplication::translate("ManagerWin", "\345\247\223\345\220\215", 0));
        ___qtreewidgetitem4->setText(0, QApplication::translate("ManagerWin", "\347\256\241\347\220\206\345\221\230\347\274\226\345\217\267", 0));
        pushButton_22->setText(QApplication::translate("ManagerWin", "\345\242\236\345\212\240\347\256\241\347\220\206\345\221\230", 0));
        pushButton_23->setText(QApplication::translate("ManagerWin", "\345\210\240\351\231\244\347\256\241\347\220\206\345\221\230", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("ManagerWin", "\347\256\241\347\220\206\345\221\230\347\256\241\347\220\206", 0));
    } // retranslateUi

};

namespace Ui {
    class ManagerWin: public Ui_ManagerWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGERWIN_H
