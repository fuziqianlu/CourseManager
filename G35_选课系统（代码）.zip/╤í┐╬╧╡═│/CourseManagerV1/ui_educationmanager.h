/********************************************************************************
** Form generated from reading UI file 'educationmanager.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDUCATIONMANAGER_H
#define UI_EDUCATIONMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_educationManagerClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QTableWidget *tableWidget_2;
    QTabWidget *tabWidget_3;
    QWidget *tab_7;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_12;
    QLabel *label_11;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_13;
    QLabel *label_15;
    QTabWidget *tabWidget_5;
    QWidget *tab_13;
    QTableWidget *tableWidget_4;
    QWidget *tab_14;
    QTableWidget *tableWidget_7;
    QWidget *tab_8;
    QHBoxLayout *horizontalLayout_10;
    QTabWidget *tabWidget_4;
    QWidget *tab_9;
    QTableWidget *tableWidget_5;
    QWidget *tab_10;
    QTableWidget *tableWidget_6;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_11;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_16;
    QLineEdit *lineEdit_4;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_17;
    QLineEdit *lineEdit_5;
    QComboBox *comboBox_5;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_14;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_18;
    QComboBox *comboBox_6;
    QLabel *label_19;
    QSpinBox *spinBox_3;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_20;
    QSpinBox *spinBox_4;
    QLabel *label_21;
    QComboBox *comboBox_7;
    QWidget *layoutWidget_4;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_22;
    QLineEdit *lineEdit_6;
    QComboBox *comboBox_8;
    QWidget *layoutWidget_5;
    QHBoxLayout *horizontalLayout_18;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_4;
    QWidget *tab_11;
    QWidget *tab_12;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout;
    QTabWidget *tabWidget_2;
    QWidget *tab_5;
    QTableWidget *tableWidget_3;
    QWidget *tab_6;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QComboBox *comboBox;
    QHBoxLayout *horizontalLayout_24;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_3;
    QComboBox *comboBox_2;
    QLabel *label_4;
    QSpinBox *spinBox;
    QLabel *label_5;
    QSpinBox *spinBox_2;
    QLabel *label_6;
    QComboBox *comboBox_3;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_7;
    QLineEdit *lineEdit_3;
    QComboBox *comboBox_4;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_2;
    QTreeWidget *treeWidget;
    QWidget *tab_3;
    QPushButton *pushButton_5;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_24;
    QLineEdit *lineEdit_12;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_23;
    QLineEdit *lineEdit_11;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_14;
    QLineEdit *lineEdit_10;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_21;
    QLabel *label_10;
    QLineEdit *lineEdit_9;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_9;
    QLineEdit *lineEdit_8;
    QWidget *layoutWidget6;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_8;
    QLineEdit *lineEdit_7;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *educationManagerClass)
    {
        if (educationManagerClass->objectName().isEmpty())
            educationManagerClass->setObjectName(QStringLiteral("educationManagerClass"));
        educationManagerClass->resize(883, 581);
        centralWidget = new QWidget(educationManagerClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setAutoFillBackground(false);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tableWidget_2 = new QTableWidget(tab);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(25, 71, 731, 361));
        tabWidget_3 = new QTabWidget(tab);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(-20, -20, 865, 506));
        tabWidget_3->setAutoFillBackground(false);
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        layoutWidget = new QWidget(tab_7);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 0, 801, 481));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_19->addWidget(label_12);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_19->addWidget(label_11);

        horizontalSpacer_4 = new QSpacerItem(58, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_4);

        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout_19->addWidget(label_13);

        label_15 = new QLabel(layoutWidget);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_19->addWidget(label_15);


        verticalLayout_2->addLayout(horizontalLayout_19);

        tabWidget_5 = new QTabWidget(layoutWidget);
        tabWidget_5->setObjectName(QStringLiteral("tabWidget_5"));
        tabWidget_5->setTabPosition(QTabWidget::West);
        tab_13 = new QWidget();
        tab_13->setObjectName(QStringLiteral("tab_13"));
        tableWidget_4 = new QTableWidget(tab_13);
        if (tableWidget_4->columnCount() < 7)
            tableWidget_4->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_4->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        tableWidget_4->setObjectName(QStringLiteral("tableWidget_4"));
        tableWidget_4->setGeometry(QRect(5, 1, 761, 441));
        tabWidget_5->addTab(tab_13, QString());
        tab_14 = new QWidget();
        tab_14->setObjectName(QStringLiteral("tab_14"));
        tableWidget_7 = new QTableWidget(tab_14);
        if (tableWidget_7->columnCount() < 7)
            tableWidget_7->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(0, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(1, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(2, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(3, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(4, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(5, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_7->setHorizontalHeaderItem(6, __qtablewidgetitem13);
        if (tableWidget_7->rowCount() < 13)
            tableWidget_7->setRowCount(13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(0, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(1, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(2, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(3, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(4, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(5, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(6, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(7, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(8, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(9, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(10, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(11, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget_7->setVerticalHeaderItem(12, __qtablewidgetitem26);
        tableWidget_7->setObjectName(QStringLiteral("tableWidget_7"));
        tableWidget_7->setGeometry(QRect(5, 1, 761, 441));
        tabWidget_5->addTab(tab_14, QString());

        verticalLayout_2->addWidget(tabWidget_5);

        tabWidget_3->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        horizontalLayout_10 = new QHBoxLayout(tab_8);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        tabWidget_4 = new QTabWidget(tab_8);
        tabWidget_4->setObjectName(QStringLiteral("tabWidget_4"));
        tabWidget_4->setTabPosition(QTabWidget::West);
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        tableWidget_5 = new QTableWidget(tab_9);
        tableWidget_5->setObjectName(QStringLiteral("tableWidget_5"));
        tableWidget_5->setGeometry(QRect(15, 21, 611, 401));
        tabWidget_4->addTab(tab_9, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName(QStringLiteral("tab_10"));
        tableWidget_6 = new QTableWidget(tab_10);
        if (tableWidget_6->columnCount() < 5)
            tableWidget_6->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(0, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(1, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(2, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(3, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(4, __qtablewidgetitem31);
        tableWidget_6->setObjectName(QStringLiteral("tableWidget_6"));
        tableWidget_6->setGeometry(QRect(20, 140, 781, 291));
        layoutWidget_2 = new QWidget(tab_10);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(20, 20, 597, 24));
        horizontalLayout_11 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_16 = new QLabel(layoutWidget_2);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_12->addWidget(label_16);

        lineEdit_4 = new QLineEdit(layoutWidget_2);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));

        horizontalLayout_12->addWidget(lineEdit_4);


        horizontalLayout_11->addLayout(horizontalLayout_12);

        horizontalSpacer_5 = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_5);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        label_17 = new QLabel(layoutWidget_2);
        label_17->setObjectName(QStringLiteral("label_17"));

        horizontalLayout_13->addWidget(label_17);

        lineEdit_5 = new QLineEdit(layoutWidget_2);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));

        horizontalLayout_13->addWidget(lineEdit_5);

        comboBox_5 = new QComboBox(layoutWidget_2);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setMaxVisibleItems(10);
        comboBox_5->setInsertPolicy(QComboBox::InsertAtBottom);

        horizontalLayout_13->addWidget(comboBox_5);


        horizontalLayout_11->addLayout(horizontalLayout_13);

        layoutWidget_3 = new QWidget(tab_10);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(20, 60, 362, 24));
        horizontalLayout_14 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        label_18 = new QLabel(layoutWidget_3);
        label_18->setObjectName(QStringLiteral("label_18"));

        horizontalLayout_15->addWidget(label_18);

        comboBox_6 = new QComboBox(layoutWidget_3);
        comboBox_6->setObjectName(QStringLiteral("comboBox_6"));

        horizontalLayout_15->addWidget(comboBox_6);

        label_19 = new QLabel(layoutWidget_3);
        label_19->setObjectName(QStringLiteral("label_19"));

        horizontalLayout_15->addWidget(label_19);

        spinBox_3 = new QSpinBox(layoutWidget_3);
        spinBox_3->setObjectName(QStringLiteral("spinBox_3"));

        horizontalLayout_15->addWidget(spinBox_3);


        horizontalLayout_14->addLayout(horizontalLayout_15);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_20 = new QLabel(layoutWidget_3);
        label_20->setObjectName(QStringLiteral("label_20"));

        horizontalLayout_16->addWidget(label_20);

        spinBox_4 = new QSpinBox(layoutWidget_3);
        spinBox_4->setObjectName(QStringLiteral("spinBox_4"));

        horizontalLayout_16->addWidget(spinBox_4);

        label_21 = new QLabel(layoutWidget_3);
        label_21->setObjectName(QStringLiteral("label_21"));

        horizontalLayout_16->addWidget(label_21);

        comboBox_7 = new QComboBox(layoutWidget_3);
        comboBox_7->setObjectName(QStringLiteral("comboBox_7"));

        horizontalLayout_16->addWidget(comboBox_7);


        horizontalLayout_14->addLayout(horizontalLayout_16);

        layoutWidget_4 = new QWidget(tab_10);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(390, 60, 241, 22));
        horizontalLayout_17 = new QHBoxLayout(layoutWidget_4);
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(0, 0, 0, 0);
        label_22 = new QLabel(layoutWidget_4);
        label_22->setObjectName(QStringLiteral("label_22"));

        horizontalLayout_17->addWidget(label_22);

        lineEdit_6 = new QLineEdit(layoutWidget_4);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));

        horizontalLayout_17->addWidget(lineEdit_6);

        comboBox_8 = new QComboBox(layoutWidget_4);
        comboBox_8->setObjectName(QStringLiteral("comboBox_8"));

        horizontalLayout_17->addWidget(comboBox_8);

        layoutWidget_5 = new QWidget(tab_10);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(370, 100, 212, 25));
        horizontalLayout_18 = new QHBoxLayout(layoutWidget_5);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(0, 0, 0, 0);
        pushButton_3 = new QPushButton(layoutWidget_5);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        horizontalLayout_18->addWidget(pushButton_3);

        horizontalSpacer_6 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_6);

        pushButton_4 = new QPushButton(layoutWidget_5);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        horizontalLayout_18->addWidget(pushButton_4);

        tabWidget_4->addTab(tab_10, QString());

        horizontalLayout_10->addWidget(tabWidget_4);

        tabWidget_3->addTab(tab_8, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName(QStringLiteral("tab_11"));
        tabWidget_3->addTab(tab_11, QString());
        tab_12 = new QWidget();
        tab_12->setObjectName(QStringLiteral("tab_12"));
        tabWidget_3->addTab(tab_12, QString());
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        horizontalLayout = new QHBoxLayout(tab_2);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        tabWidget_2 = new QTabWidget(tab_2);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setTabPosition(QTabWidget::West);
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        tableWidget_3 = new QTableWidget(tab_5);
        if (tableWidget_3->columnCount() < 4)
            tableWidget_3->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(0, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(1, __qtablewidgetitem33);
        QTableWidgetItem *__qtablewidgetitem34 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(2, __qtablewidgetitem34);
        QTableWidgetItem *__qtablewidgetitem35 = new QTableWidgetItem();
        tableWidget_3->setHorizontalHeaderItem(3, __qtablewidgetitem35);
        tableWidget_3->setObjectName(QStringLiteral("tableWidget_3"));
        tableWidget_3->setGeometry(QRect(10, 10, 771, 461));
        tabWidget_2->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        verticalLayout_3 = new QVBoxLayout(tab_6);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label = new QLabel(tab_6);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        lineEdit = new QLineEdit(tab_6);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        horizontalLayout_2->addWidget(lineEdit);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        horizontalSpacer = new QSpacerItem(118, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_2 = new QLabel(tab_6);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_3->addWidget(label_2);

        lineEdit_2 = new QLineEdit(tab_6);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        horizontalLayout_3->addWidget(lineEdit_2);

        comboBox = new QComboBox(tab_6);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setMaxVisibleItems(10);
        comboBox->setInsertPolicy(QComboBox::InsertAtBottom);

        horizontalLayout_3->addWidget(comboBox);


        horizontalLayout_4->addLayout(horizontalLayout_3);


        verticalLayout_3->addLayout(horizontalLayout_4);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_3 = new QLabel(tab_6);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_5->addWidget(label_3);

        comboBox_2 = new QComboBox(tab_6);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));

        horizontalLayout_5->addWidget(comboBox_2);

        label_4 = new QLabel(tab_6);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_5->addWidget(label_4);

        spinBox = new QSpinBox(tab_6);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        spinBox->setMinimum(1);
        spinBox->setMaximum(13);

        horizontalLayout_5->addWidget(spinBox);

        label_5 = new QLabel(tab_6);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_5->addWidget(label_5);

        spinBox_2 = new QSpinBox(tab_6);
        spinBox_2->setObjectName(QStringLiteral("spinBox_2"));
        spinBox_2->setMinimum(1);
        spinBox_2->setMaximum(13);

        horizontalLayout_5->addWidget(spinBox_2);

        label_6 = new QLabel(tab_6);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_5->addWidget(label_6);

        comboBox_3 = new QComboBox(tab_6);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));

        horizontalLayout_5->addWidget(comboBox_3);


        horizontalLayout_24->addLayout(horizontalLayout_5);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_7 = new QLabel(tab_6);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_8->addWidget(label_7);

        lineEdit_3 = new QLineEdit(tab_6);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        horizontalLayout_8->addWidget(lineEdit_3);

        comboBox_4 = new QComboBox(tab_6);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));

        horizontalLayout_8->addWidget(comboBox_4);


        horizontalLayout_24->addLayout(horizontalLayout_8);


        verticalLayout_3->addLayout(horizontalLayout_24);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        horizontalSpacer_3 = new QSpacerItem(508, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_3);

        pushButton = new QPushButton(tab_6);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout_9->addWidget(pushButton);

        horizontalSpacer_2 = new QSpacerItem(48, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_2);

        pushButton_2 = new QPushButton(tab_6);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout_9->addWidget(pushButton_2);


        verticalLayout_3->addLayout(horizontalLayout_9);

        treeWidget = new QTreeWidget(tab_6);
        treeWidget->setObjectName(QStringLiteral("treeWidget"));
        treeWidget->header()->setDefaultSectionSize(90);

        verticalLayout_3->addWidget(treeWidget);

        tabWidget_2->addTab(tab_6, QString());

        horizontalLayout->addWidget(tabWidget_2);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        pushButton_5 = new QPushButton(tab_3);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(190, 300, 75, 23));
        layoutWidget1 = new QWidget(tab_3);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(150, 230, 177, 22));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        label_24 = new QLabel(layoutWidget1);
        label_24->setObjectName(QStringLiteral("label_24"));

        horizontalLayout_6->addWidget(label_24);

        lineEdit_12 = new QLineEdit(layoutWidget1);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));

        horizontalLayout_6->addWidget(lineEdit_12);

        layoutWidget2 = new QWidget(tab_3);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(150, 200, 177, 22));
        horizontalLayout_7 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_23 = new QLabel(layoutWidget2);
        label_23->setObjectName(QStringLiteral("label_23"));

        horizontalLayout_7->addWidget(label_23);

        lineEdit_11 = new QLineEdit(layoutWidget2);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));

        horizontalLayout_7->addWidget(lineEdit_11);

        layoutWidget3 = new QWidget(tab_3);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(150, 170, 177, 22));
        horizontalLayout_20 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        horizontalLayout_20->setContentsMargins(0, 0, 0, 0);
        label_14 = new QLabel(layoutWidget3);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_20->addWidget(label_14);

        lineEdit_10 = new QLineEdit(layoutWidget3);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));

        horizontalLayout_20->addWidget(lineEdit_10);

        layoutWidget4 = new QWidget(tab_3);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(150, 130, 177, 22));
        horizontalLayout_21 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        horizontalLayout_21->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(layoutWidget4);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_21->addWidget(label_10);

        lineEdit_9 = new QLineEdit(layoutWidget4);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));

        horizontalLayout_21->addWidget(lineEdit_9);

        layoutWidget5 = new QWidget(tab_3);
        layoutWidget5->setObjectName(QStringLiteral("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(150, 90, 177, 22));
        horizontalLayout_22 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        horizontalLayout_22->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget5);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_22->addWidget(label_9);

        lineEdit_8 = new QLineEdit(layoutWidget5);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));

        horizontalLayout_22->addWidget(lineEdit_8);

        layoutWidget6 = new QWidget(tab_3);
        layoutWidget6->setObjectName(QStringLiteral("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(150, 50, 177, 22));
        horizontalLayout_23 = new QHBoxLayout(layoutWidget6);
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        horizontalLayout_23->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(layoutWidget6);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_23->addWidget(label_8);

        lineEdit_7 = new QLineEdit(layoutWidget6);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));

        horizontalLayout_23->addWidget(lineEdit_7);

        tabWidget->addTab(tab_3, QString());

        verticalLayout->addWidget(tabWidget);

        educationManagerClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(educationManagerClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 883, 23));
        educationManagerClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(educationManagerClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        educationManagerClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(educationManagerClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        educationManagerClass->setStatusBar(statusBar);

        retranslateUi(educationManagerClass);

        tabWidget->setCurrentIndex(0);
        tabWidget_3->setCurrentIndex(0);
        tabWidget_5->setCurrentIndex(0);
        tabWidget_4->setCurrentIndex(1);
        tabWidget_2->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(educationManagerClass);
    } // setupUi

    void retranslateUi(QMainWindow *educationManagerClass)
    {
        educationManagerClass->setWindowTitle(QApplication::translate("educationManagerClass", "educationManager", 0));
        label_12->setText(QApplication::translate("educationManagerClass", "\345\247\223\345\220\215\357\274\232", 0));
        label_11->setText(QApplication::translate("educationManagerClass", "*****", 0));
        label_13->setText(QApplication::translate("educationManagerClass", "\345\255\246\345\217\267\357\274\232", 0));
        label_15->setText(QApplication::translate("educationManagerClass", "0000000000", 0));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_4->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\347\274\226\345\217\267", 0));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_4->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\220\215\347\247\260", 0));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_4->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("educationManagerClass", "\346\225\231\345\270\210\345\220\215\347\247\260", 0));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_4->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("educationManagerClass", "\346\227\245\346\234\237", 0));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_4->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("educationManagerClass", "\345\274\200\345\247\213\350\212\202\346\225\260", 0));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_4->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("educationManagerClass", "\347\273\223\346\235\237\350\212\202\346\225\260", 0));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_4->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QApplication::translate("educationManagerClass", "\344\270\212\350\257\276\345\234\260\347\202\271", 0));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_13), QApplication::translate("educationManagerClass", "\345\210\227\350\241\250\346\250\241\345\274\217", 0));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_7->horizontalHeaderItem(0);
        ___qtablewidgetitem7->setText(QApplication::translate("educationManagerClass", "\345\221\250\344\270\200", 0));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_7->horizontalHeaderItem(1);
        ___qtablewidgetitem8->setText(QApplication::translate("educationManagerClass", "\345\221\250\344\272\214", 0));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_7->horizontalHeaderItem(2);
        ___qtablewidgetitem9->setText(QApplication::translate("educationManagerClass", "\345\221\250\344\270\211", 0));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_7->horizontalHeaderItem(3);
        ___qtablewidgetitem10->setText(QApplication::translate("educationManagerClass", "\345\221\250\345\233\233", 0));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_7->horizontalHeaderItem(4);
        ___qtablewidgetitem11->setText(QApplication::translate("educationManagerClass", "\345\221\250\344\272\224", 0));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_7->horizontalHeaderItem(5);
        ___qtablewidgetitem12->setText(QApplication::translate("educationManagerClass", "\345\221\250\345\205\255", 0));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_7->horizontalHeaderItem(6);
        ___qtablewidgetitem13->setText(QApplication::translate("educationManagerClass", "\345\221\250\346\227\245", 0));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_7->verticalHeaderItem(0);
        ___qtablewidgetitem14->setText(QApplication::translate("educationManagerClass", "1", 0));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_7->verticalHeaderItem(1);
        ___qtablewidgetitem15->setText(QApplication::translate("educationManagerClass", "2", 0));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_7->verticalHeaderItem(2);
        ___qtablewidgetitem16->setText(QApplication::translate("educationManagerClass", "3", 0));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget_7->verticalHeaderItem(3);
        ___qtablewidgetitem17->setText(QApplication::translate("educationManagerClass", "4", 0));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget_7->verticalHeaderItem(4);
        ___qtablewidgetitem18->setText(QApplication::translate("educationManagerClass", "5", 0));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget_7->verticalHeaderItem(5);
        ___qtablewidgetitem19->setText(QApplication::translate("educationManagerClass", "6", 0));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget_7->verticalHeaderItem(6);
        ___qtablewidgetitem20->setText(QApplication::translate("educationManagerClass", "7", 0));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget_7->verticalHeaderItem(7);
        ___qtablewidgetitem21->setText(QApplication::translate("educationManagerClass", "8", 0));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget_7->verticalHeaderItem(8);
        ___qtablewidgetitem22->setText(QApplication::translate("educationManagerClass", "9", 0));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget_7->verticalHeaderItem(9);
        ___qtablewidgetitem23->setText(QApplication::translate("educationManagerClass", "10", 0));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget_7->verticalHeaderItem(10);
        ___qtablewidgetitem24->setText(QApplication::translate("educationManagerClass", "11", 0));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget_7->verticalHeaderItem(11);
        ___qtablewidgetitem25->setText(QApplication::translate("educationManagerClass", "12", 0));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidget_7->verticalHeaderItem(12);
        ___qtablewidgetitem26->setText(QApplication::translate("educationManagerClass", "13", 0));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_14), QApplication::translate("educationManagerClass", "\350\241\250\346\240\274\346\250\241\345\274\217", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_7), QApplication::translate("educationManagerClass", " \346\210\221\347\232\204\350\257\276\350\241\250", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_9), QApplication::translate("educationManagerClass", "\345\205\250\351\203\250\350\257\276\347\250\213", 0));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget_6->horizontalHeaderItem(0);
        ___qtablewidgetitem27->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\347\274\226\345\217\267", 0));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget_6->horizontalHeaderItem(1);
        ___qtablewidgetitem28->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\220\215\347\247\260", 0));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidget_6->horizontalHeaderItem(2);
        ___qtablewidgetitem29->setText(QApplication::translate("educationManagerClass", "\344\270\212\350\257\276\346\227\266\351\227\264", 0));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidget_6->horizontalHeaderItem(3);
        ___qtablewidgetitem30->setText(QApplication::translate("educationManagerClass", "\346\225\231\345\270\210", 0));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidget_6->horizontalHeaderItem(4);
        ___qtablewidgetitem31->setText(QApplication::translate("educationManagerClass", "\344\272\272\346\225\260", 0));
        label_16->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\217\267\357\274\232", 0));
        label_17->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\220\215\347\247\260\357\274\232", 0));
        comboBox_5->clear();
        comboBox_5->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        comboBox_5->setCurrentText(QApplication::translate("educationManagerClass", "\346\210\226", 0));
        label_18->setText(QApplication::translate("educationManagerClass", "\346\227\266\351\227\264\357\274\232", 0));
        comboBox_6->clear();
        comboBox_6->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        label_19->setText(QApplication::translate("educationManagerClass", "\347\254\254", 0));
        label_20->setText(QApplication::translate("educationManagerClass", "\350\212\202\350\207\263\347\254\254", 0));
        label_21->setText(QApplication::translate("educationManagerClass", "\350\212\202", 0));
        comboBox_7->clear();
        comboBox_7->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        label_22->setText(QApplication::translate("educationManagerClass", "\344\270\223\344\270\232\357\274\232", 0));
        comboBox_8->clear();
        comboBox_8->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        pushButton_3->setText(QApplication::translate("educationManagerClass", "\346\220\234\347\264\242", 0));
        pushButton_4->setText(QApplication::translate("educationManagerClass", "\346\270\205\347\251\272", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_10), QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\346\220\234\347\264\242", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_8), QApplication::translate("educationManagerClass", "\350\257\276\347\250\213", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_11), QApplication::translate("educationManagerClass", "\344\270\252\344\272\272\344\277\241\346\201\257", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_12), QApplication::translate("educationManagerClass", "\345\205\266\344\273\226", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("educationManagerClass", " \346\210\221\347\232\204\350\257\276\350\241\250", 0));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidget_3->horizontalHeaderItem(0);
        ___qtablewidgetitem32->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\347\274\226\345\217\267", 0));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidget_3->horizontalHeaderItem(1);
        ___qtablewidgetitem33->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\220\215\347\247\260", 0));
        QTableWidgetItem *___qtablewidgetitem34 = tableWidget_3->horizontalHeaderItem(2);
        ___qtablewidgetitem34->setText(QApplication::translate("educationManagerClass", "\344\270\223\344\270\232", 0));
        QTableWidgetItem *___qtablewidgetitem35 = tableWidget_3->horizontalHeaderItem(3);
        ___qtablewidgetitem35->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\344\273\213\347\273\215", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_5), QApplication::translate("educationManagerClass", "\345\205\250\351\203\250\350\257\276\347\250\213", 0));
        label->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\217\267\357\274\232", 0));
        label_2->setText(QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\220\215\347\247\260\357\274\232", 0));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        comboBox->setCurrentText(QApplication::translate("educationManagerClass", "\346\210\226", 0));
        label_3->setText(QApplication::translate("educationManagerClass", "\346\227\266\351\227\264\357\274\232", 0));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\345\221\250\344\270\200", 0)
         << QApplication::translate("educationManagerClass", "\345\221\250\344\272\214", 0)
         << QApplication::translate("educationManagerClass", "\345\221\250\344\270\211", 0)
         << QApplication::translate("educationManagerClass", "\345\221\250\345\233\233", 0)
         << QApplication::translate("educationManagerClass", "\345\221\250\344\272\224", 0)
         << QApplication::translate("educationManagerClass", "\345\221\250\345\205\255", 0)
         << QApplication::translate("educationManagerClass", "\345\221\250\346\227\245", 0)
        );
        label_4->setText(QApplication::translate("educationManagerClass", "\347\254\254", 0));
        label_5->setText(QApplication::translate("educationManagerClass", "\350\212\202\350\207\263\347\254\254", 0));
        label_6->setText(QApplication::translate("educationManagerClass", "\350\212\202", 0));
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        label_7->setText(QApplication::translate("educationManagerClass", "\344\270\223\344\270\232\357\274\232", 0));
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("educationManagerClass", "\346\210\226", 0)
         << QApplication::translate("educationManagerClass", "\344\270\216", 0)
        );
        pushButton->setText(QApplication::translate("educationManagerClass", "\346\220\234\347\264\242", 0));
        pushButton_2->setText(QApplication::translate("educationManagerClass", "\346\270\205\347\251\272", 0));
        QTreeWidgetItem *___qtreewidgetitem = treeWidget->headerItem();
        ___qtreewidgetitem->setText(9, QApplication::translate("educationManagerClass", "\350\277\233\345\205\245\351\200\211\350\257\276", 0));
        ___qtreewidgetitem->setText(8, QApplication::translate("educationManagerClass", "\347\216\260\346\234\211\345\256\271\351\207\217", 0));
        ___qtreewidgetitem->setText(7, QApplication::translate("educationManagerClass", "\346\234\200\345\244\247\345\256\271\351\207\217", 0));
        ___qtreewidgetitem->setText(6, QApplication::translate("educationManagerClass", "\344\270\212\350\257\276\345\234\260\347\202\271", 0));
        ___qtreewidgetitem->setText(5, QApplication::translate("educationManagerClass", "\347\273\223\346\235\237\350\212\202\346\225\260", 0));
        ___qtreewidgetitem->setText(4, QApplication::translate("educationManagerClass", "\345\274\200\345\247\213\350\212\202\346\225\260", 0));
        ___qtreewidgetitem->setText(3, QApplication::translate("educationManagerClass", "\346\227\245\346\234\237", 0));
        ___qtreewidgetitem->setText(2, QApplication::translate("educationManagerClass", "\346\225\231\345\270\210\345\220\215\347\247\260", 0));
        ___qtreewidgetitem->setText(1, QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\345\220\215\347\247\260", 0));
        ___qtreewidgetitem->setText(0, QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\347\274\226\345\217\267", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_6), QApplication::translate("educationManagerClass", "\350\257\276\347\250\213\346\220\234\347\264\242", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("educationManagerClass", "\350\257\276\347\250\213", 0));
        pushButton_5->setText(QApplication::translate("educationManagerClass", " \346\211\247\350\241\214\344\277\256\346\224\271", 0));
        label_24->setText(QApplication::translate("educationManagerClass", "\351\202\256\347\256\261\357\274\232", 0));
        label_23->setText(QApplication::translate("educationManagerClass", "\347\224\265\350\257\235\357\274\232", 0));
        label_14->setText(QApplication::translate("educationManagerClass", "\345\271\264\347\272\247\357\274\232", 0));
        label_10->setText(QApplication::translate("educationManagerClass", "\347\217\255\347\272\247\357\274\232", 0));
        label_9->setText(QApplication::translate("educationManagerClass", "\345\247\223\345\220\215\357\274\232", 0));
        label_8->setText(QApplication::translate("educationManagerClass", "\345\255\246\345\217\267\357\274\232", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("educationManagerClass", "\344\270\252\344\272\272\344\277\241\346\201\257", 0));
    } // retranslateUi

};

namespace Ui {
    class educationManagerClass: public Ui_educationManagerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDUCATIONMANAGER_H
